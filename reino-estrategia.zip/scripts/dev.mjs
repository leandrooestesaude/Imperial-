// Sobe servidor (8787) e cliente Vite (3000) juntos em modo desenvolvimento.
import { spawn } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const procs = [];
let shuttingDown = false;

function run(name, command, args, cwd) {
  const child = spawn(command, args, {
    cwd,
    stdio: ['ignore', 'pipe', 'pipe'],
    env: process.env,
  });
  child.stdout.on('data', (chunk) => process.stdout.write(`[${name}] ${chunk}`));
  child.stderr.on('data', (chunk) => process.stderr.write(`[${name}] ${chunk}`));
  child.on('exit', (code) => {
    if (shuttingDown) return;
    console.log(`[${name}] encerrado com código ${code}`);
    shutdown(code ?? 0);
  });
  procs.push(child);
}

function shutdown(code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  for (const proc of procs) proc.kill('SIGTERM');
  setTimeout(() => process.exit(code), 300);
}

process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));

run('servidor', process.execPath, ['server/src/index.js'], root);
run('cliente', join(root, 'node_modules', '.bin', 'vite'), [
  '--host', '0.0.0.0',
  '--port', '3000',
  '--strictPort',
], join(root, 'client'));
