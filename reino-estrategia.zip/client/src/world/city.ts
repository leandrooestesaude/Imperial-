import { mulberry32 } from './noise';
import type { Hotspot, Scene } from './scene';
import { createCanvas, makeBushSprite, makeRockSprite, makeTreeSprite } from './terrain';

const TAU = Math.PI * 2;

const WALL = { x0: 392, y0: 158, x1: 1528, y1: 886, t: 30 };
const GATE = { x0: 898, x1: 1022 };
const PLAZA = { x: 960, y: 470, rx: 214, ry: 146 };

const ROOF = {
  terracotta: '#ab4a32',
  blue: '#476c85',
  gold: '#c6a04c',
  brown: '#7c5a36',
};

const STONE = '#cbc1a9';
const SAND = '#cdb894';

function shade(hex: string, factor: number): string {
  const value = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.round(((value >> 16) & 255) * factor));
  const g = Math.min(255, Math.round(((value >> 8) & 255) * factor));
  const b = Math.min(255, Math.round((value & 255) * factor));
  return `rgb(${r}, ${g}, ${b})`;
}

function rr(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  g.beginPath();
  g.roundRect(x, y, w, h, r);
}

function fillRR(
  g: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
  color: string,
): void {
  g.fillStyle = color;
  rr(g, x, y, w, h, r);
  g.fill();
}

function groundShadow(g: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number): void {
  g.fillStyle = 'rgba(24, 36, 16, 0.26)';
  g.beginPath();
  g.ellipse(x, y, rx, ry, 0, 0, TAU);
  g.fill();
}

function paintGround(g: CanvasRenderingContext2D, rand: () => number, width: number, height: number): void {
  const base = g.createLinearGradient(0, 0, 0, height);
  base.addColorStop(0, '#709549');
  base.addColorStop(1, '#5c7f3d');
  g.fillStyle = base;
  g.fillRect(0, 0, width, height);

  for (let i = 0; i < 90; i++) {
    const x = rand() * width;
    const y = rand() * height;
    const radius = 130 + rand() * 260;
    const light = rand() > 0.45;
    const glow = g.createRadialGradient(x, y, 0, x, y, radius);
    glow.addColorStop(0, light ? 'rgba(166, 194, 112, 0.3)' : 'rgba(56, 86, 40, 0.3)');
    glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
    g.fillStyle = glow;
    g.beginPath();
    g.arc(x, y, radius, 0, TAU);
    g.fill();
  }

  // gramado aparado dentro da muralha
  fillRR(g, WALL.x0, WALL.y0, WALL.x1 - WALL.x0, WALL.y1 - WALL.y0, 28, 'rgba(198, 210, 138, 0.16)');
}

function paintRoads(g: CanvasRenderingContext2D): void {
  g.save();
  g.lineCap = 'round';

  // estrada principal de fora até o portão
  g.strokeStyle = 'rgba(122, 100, 64, 0.4)';
  g.lineWidth = 74;
  g.beginPath();
  g.moveTo(960, 880);
  g.bezierCurveTo(944, 946, 966, 1002, 984, 1092);
  g.stroke();
  g.strokeStyle = '#c4a677';
  g.lineWidth = 62;
  g.beginPath();
  g.moveTo(960, 880);
  g.bezierCurveTo(944, 946, 966, 1002, 984, 1092);
  g.stroke();

  // eixo do portão até a praça
  g.strokeStyle = '#c9b795';
  g.lineWidth = 48;
  g.beginPath();
  g.moveTo(960, 900);
  g.lineTo(960, 600);
  g.stroke();

  // via transversal, escondida sob a praça
  g.lineWidth = 40;
  g.beginPath();
  g.moveTo(424, 520);
  g.lineTo(1496, 520);
  g.stroke();

  g.strokeStyle = 'rgba(148, 128, 94, 0.45)';
  g.lineWidth = 2;
  g.beginPath();
  g.moveTo(424, 542);
  g.lineTo(1496, 542);
  g.stroke();
  g.restore();
}

function paintPlaza(g: CanvasRenderingContext2D): void {
  const { x, y, rx, ry } = PLAZA;

  g.save();
  const stone = g.createRadialGradient(x - 40, y - 40, 40, x, y, rx);
  stone.addColorStop(0, '#dbd1b8');
  stone.addColorStop(0.65, '#c9bda3');
  stone.addColorStop(1, '#ada086');
  g.fillStyle = stone;
  g.beginPath();
  g.ellipse(x, y, rx, ry, 0, 0, TAU);
  g.fill();

  g.beginPath();
  g.ellipse(x, y, rx, ry, 0, 0, TAU);
  g.clip();
  g.strokeStyle = 'rgba(124, 110, 86, 0.22)';
  g.lineWidth = 2;
  for (let ring = 46; ring < rx; ring += 44) {
    g.beginPath();
    g.ellipse(x, y, ring, ring * (ry / rx), 0, 0, TAU);
    g.stroke();
  }
  for (let i = 0; i < 20; i++) {
    const angle = (i / 20) * TAU;
    g.beginPath();
    g.moveTo(x + Math.cos(angle) * 46, y + Math.sin(angle) * 32);
    g.lineTo(x + Math.cos(angle) * rx, y + Math.sin(angle) * ry);
    g.stroke();
  }
  g.restore();

  g.strokeStyle = 'rgba(120, 106, 82, 0.4)';
  g.lineWidth = 3;
  g.beginPath();
  g.ellipse(x, y, rx, ry, 0, 0, TAU);
  g.stroke();
}

function drawTower(g: CanvasRenderingContext2D, x: number, y: number, radius: number, roof: string): void {
  groundShadow(g, x + radius * 0.22, y + radius * 0.45, radius * 1.05, radius * 0.68);

  const stone = g.createRadialGradient(
    x - radius * 0.3,
    y - radius * 0.32,
    radius * 0.2,
    x,
    y,
    radius,
  );
  stone.addColorStop(0, '#e2d9c2');
  stone.addColorStop(1, '#b0a58a');
  g.fillStyle = stone;
  g.beginPath();
  g.arc(x, y, radius, 0, TAU);
  g.fill();
  g.strokeStyle = '#94896f';
  g.lineWidth = 2;
  g.stroke();

  g.fillStyle = roof;
  g.beginPath();
  g.arc(x, y, radius * 0.64, 0, TAU);
  g.fill();
  g.strokeStyle = 'rgba(58, 32, 22, 0.45)';
  g.lineWidth = 1.5;
  g.stroke();
  g.fillStyle = 'rgba(255, 238, 206, 0.28)';
  g.beginPath();
  g.arc(x - radius * 0.16, y - radius * 0.18, radius * 0.22, 0, TAU);
  g.fill();
}

function drawBuilding(
  g: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  w: number,
  h: number,
  roof: string,
  wall = '#d8cfb6',
): void {
  g.fillStyle = 'rgba(24, 36, 16, 0.3)';
  g.beginPath();
  g.ellipse(cx + 8, cy + h * 0.52, w * 0.56, h * 0.3, 0, 0, TAU);
  g.fill();

  fillRR(g, cx - w / 2 - 7, cy - h / 2 - 4, w + 14, h + 12, 10, wall);
  g.strokeStyle = 'rgba(96, 82, 58, 0.4)';
  g.lineWidth = 2;
  rr(g, cx - w / 2 - 7, cy - h / 2 - 4, w + 14, h + 12, 10);
  g.stroke();

  g.save();
  rr(g, cx - w / 2, cy - h / 2, w, h, 9);
  g.clip();
  g.fillStyle = shade(roof, 1.12);
  g.fillRect(cx - w / 2, cy - h / 2, w, h / 2);
  g.fillStyle = roof;
  g.fillRect(cx - w / 2, cy, w, h / 2);
  g.fillStyle = 'rgba(255, 245, 220, 0.16)';
  g.fillRect(cx - w / 2, cy - h / 2 + 3, w, h * 0.16);
  g.restore();

  g.strokeStyle = 'rgba(52, 36, 24, 0.45)';
  g.lineWidth = 2;
  rr(g, cx - w / 2, cy - h / 2, w, h, 9);
  g.stroke();

  g.strokeStyle = 'rgba(52, 36, 24, 0.28)';
  g.lineWidth = 2;
  g.beginPath();
  g.moveTo(cx - w / 2 + 8, cy);
  g.lineTo(cx + w / 2 - 8, cy);
  g.stroke();
}

function paintWalls(g: CanvasRenderingContext2D): void {
  const { x0, y0, x1, y1, t } = WALL;

  fillRR(g, x0 - 8, y0 - 8, x1 - x0 + 16, y1 - y0 + 18, 30, 'rgba(26, 38, 18, 0.24)');

  g.fillStyle = STONE;
  g.fillRect(x0, y0, t, y1 - y0);
  g.fillRect(x1 - t, y0, t, y1 - y0);
  g.fillRect(x0, y0, x1 - x0, t);
  g.fillRect(x0, y1 - t, GATE.x0 - x0, t);
  g.fillRect(GATE.x1, y1 - t, x1 - GATE.x1, t);

  // textura de pedra
  g.fillStyle = 'rgba(160, 148, 120, 0.55)';
  for (let x = x0 + 12; x < x1 - 8; x += 34) {
    g.fillRect(x, y0 + 5, 16, 8);
    if (x < GATE.x0 - 20 || x > GATE.x1 + 4) g.fillRect(x, y1 - t + 5, 16, 8);
  }
  for (let y = y0 + 12; y < y1 - 8; y += 34) {
    g.fillRect(x0 + 5, y, 8, 16);
    g.fillRect(x1 - t + 5, y, 8, 16);
  }

  g.strokeStyle = 'rgba(140, 128, 102, 0.9)';
  g.lineWidth = 3;
  g.strokeRect(x0 + t / 2, y0 + t / 2, x1 - x0 - t, y1 - y0 - t);

  const towers: Array<[number, number]> = [
    [x0, y0],
    [x1, y0],
    [x0, y1],
    [x1, y1],
    [(x0 + x1) / 2, y0],
    [x0, (y0 + y1) / 2],
    [x1, (y0 + y1) / 2],
  ];
  for (const [x, y] of towers) drawTower(g, x, y, 27, '#a3492f');

  // portão: torres flanqueando e arco de madeira
  drawTower(g, GATE.x0, y1, 30, '#a3492f');
  drawTower(g, GATE.x1, y1, 30, '#a3492f');
  fillRR(g, GATE.x0 + 6, y1 - t - 3, GATE.x1 - GATE.x0 - 12, t + 6, 7, '#7d5b36');
  g.strokeStyle = 'rgba(46, 32, 20, 0.5)';
  g.lineWidth = 2;
  rr(g, GATE.x0 + 6, y1 - t - 3, GATE.x1 - GATE.x0 - 12, t + 6, 7);
  g.stroke();
  g.strokeStyle = 'rgba(52, 38, 22, 0.3)';
  g.lineWidth = 1.5;
  for (let x = GATE.x0 + 18; x < GATE.x1 - 10; x += 14) {
    g.beginPath();
    g.moveTo(x, y1 - t);
    g.lineTo(x, y1 + 2);
    g.stroke();
  }
}

function paintCastle(g: CanvasRenderingContext2D): void {
  const cx = 960;
  const cy = 452;
  const w = 340;
  const h = 240;

  groundShadow(g, cx + 16, cy + h * 0.42, w * 0.62, h * 0.38);

  fillRR(g, cx - w / 2, cy - h / 2, w, h, 22, STONE);
  g.strokeStyle = '#9b9077';
  g.lineWidth = 3;
  rr(g, cx - w / 2, cy - h / 2, w, h, 22);
  g.stroke();

  // ameias da muralha interna
  g.fillStyle = '#b2a78c';
  for (let x = cx - w / 2 + 16; x < cx + w / 2 - 12; x += 28) {
    g.fillRect(x, cy - h / 2 + 4, 14, 9);
    g.fillRect(x, cy + h / 2 - 13, 14, 9);
  }
  for (let y = cy - h / 2 + 16; y < cy + h / 2 - 12; y += 28) {
    g.fillRect(cx - w / 2 + 4, y, 9, 14);
    g.fillRect(cx + w / 2 - 13, y, 9, 14);
  }

  // pátio interno
  fillRR(g, cx - 96, cy - 66, 192, 140, 16, '#d9d0b8');

  for (const [dx, dy] of [
    [-1, -1],
    [1, -1],
    [-1, 1],
    [1, 1],
  ]) {
    drawTower(g, cx + (dx * w) / 2, cy + (dy * h) / 2, 28, '#8f3f2a');
  }

  drawBuilding(g, cx, cy + 6, 156, 106, '#9b3f2a', '#d3c7ab');
  // torres do torreão principal
  for (const [dx, dy] of [
    [-1, -1],
    [1, -1],
    [-1, 1],
    [1, 1],
  ]) {
    drawTower(g, cx + (dx * 156) / 2, cy + 6 + (dy * 106) / 2, 14, '#c6a04c');
  }
  drawBuilding(g, cx, cy - 58, 96, 60, ROOF.gold, '#ded2b6');

  // mastro e bandeira
  g.strokeStyle = '#5c4a2e';
  g.lineWidth = 3;
  g.beginPath();
  g.moveTo(cx, cy - 96);
  g.lineTo(cx, cy - 146);
  g.stroke();
  g.fillStyle = '#e0be62';
  g.beginPath();
  g.moveTo(cx, cy - 146);
  g.lineTo(cx + 34, cy - 138);
  g.lineTo(cx, cy - 128);
  g.closePath();
  g.fill();
  g.strokeStyle = 'rgba(120, 90, 30, 0.5)';
  g.lineWidth = 1;
  g.stroke();
}

function paintFarm(g: CanvasRenderingContext2D): void {
  const columns = [516, 660];
  const rows = [596, 726];

  for (const y of rows) {
    for (const x of columns) {
      fillRR(g, x, y, 128, 118, 10, '#8d7749');
      g.fillStyle = 'rgba(60, 44, 26, 0.3)';
      for (let i = 12; i < 112; i += 17) g.fillRect(x + 8, y + i, 112, 5);

      g.fillStyle = '#6f9a43';
      for (let i = 12; i < 112; i += 17) {
        for (let j = 14; j < 118; j += 15) {
          g.beginPath();
          g.arc(x + j, y + i + 2, 2.8, 0, TAU);
          g.fill();
        }
      }
      g.strokeStyle = 'rgba(74, 58, 34, 0.55)';
      g.lineWidth = 2;
      rr(g, x, y, 128, 118, 10);
      g.stroke();
    }
  }

  // cerca
  g.strokeStyle = 'rgba(122, 96, 60, 0.75)';
  g.lineWidth = 2;
  g.strokeRect(504, 584, 296, 272);
}

function drawLogStack(g: CanvasRenderingContext2D, x: number, y: number): void {
  for (let row = 0; row < 3; row++) {
    for (let i = 0; i < 3; i++) {
      const lx = x - 40 + i * 26 + row * 4;
      const ly = y - row * 11;
      fillRR(g, lx, ly, 40, 10, 5, '#8a6741');
      g.fillStyle = '#cfb184';
      g.beginPath();
      g.ellipse(lx + 40, ly + 5, 4, 5, 0, 0, TAU);
      g.fill();
    }
  }
}

function paintLumberCamp(g: CanvasRenderingContext2D): void {
  fillRR(g, 468, 224, 300, 214, 28, 'rgba(152, 128, 88, 0.35)');
  drawBuilding(g, 596, 300, 146, 104, ROOF.brown, '#cbbfa4');
  drawLogStack(g, 690, 386);
  drawLogStack(g, 750, 344);
  g.fillStyle = '#d6c6a0';
  g.beginPath();
  g.arc(650, 392, 13, 0, TAU);
  g.fill();
  g.strokeStyle = '#9a8460';
  g.lineWidth = 2;
  g.stroke();
}

function paintBarracks(g: CanvasRenderingContext2D): void {
  drawBuilding(g, 1310, 312, 214, 128, ROOF.blue, '#d5cbb2');

  fillRR(g, 1212, 402, 200, 128, 20, SAND);
  g.strokeStyle = 'rgba(122, 96, 60, 0.7)';
  g.lineWidth = 2;
  rr(g, 1212, 402, 200, 128, 20);
  g.stroke();

  // bonecos de treino
  for (const x of [1258, 1330]) {
    g.strokeStyle = '#6b5334';
    g.lineWidth = 3;
    g.beginPath();
    g.moveTo(x, 452);
    g.lineTo(x, 490);
    g.moveTo(x - 14, 466);
    g.lineTo(x + 14, 466);
    g.stroke();
    g.fillStyle = '#c8a768';
    g.beginPath();
    g.arc(x, 446, 11, 0, TAU);
    g.fill();
  }
}

function drawStall(g: CanvasRenderingContext2D, x: number, y: number, color: string): void {
  groundShadow(g, x + 4, y + 24, 54, 18);
  fillRR(g, x - 42, y - 2, 84, 28, 6, '#a98454');
  g.strokeStyle = 'rgba(70, 52, 32, 0.4)';
  g.lineWidth = 2;
  rr(g, x - 42, y - 2, 84, 28, 6);
  g.stroke();

  const stripes = 6;
  const stripeWidth = 92 / stripes;
  for (let i = 0; i < stripes; i++) {
    g.fillStyle = i % 2 === 0 ? color : '#f0e6cf';
    g.fillRect(x - 46 + i * stripeWidth, y - 32, stripeWidth, 30);
  }
  g.strokeStyle = 'rgba(60, 44, 28, 0.45)';
  g.lineWidth = 2;
  g.strokeRect(x - 46, y - 32, 92, 30);
}

function paintMarket(g: CanvasRenderingContext2D): void {
  fillRR(g, 1196, 604, 292, 196, 26, 'rgba(152, 128, 88, 0.3)');
  drawStall(g, 1252, 662, '#a9492f');
  drawStall(g, 1372, 700, '#3f6f8a');
  drawStall(g, 1300, 754, '#8a6a2f');
}

function paintHouses(g: CanvasRenderingContext2D): void {
  drawBuilding(g, 688, 452, 118, 88, ROOF.terracotta);
  drawBuilding(g, 1232, 452, 118, 88, ROOF.brown);
  drawBuilding(g, 1148, 728, 112, 84, ROOF.terracotta);
}

function paintWell(g: CanvasRenderingContext2D): void {
  const x = 878;
  const y = 664;
  groundShadow(g, x + 3, y + 14, 30, 12);

  g.fillStyle = '#b6ac93';
  g.beginPath();
  g.arc(x, y, 26, 0, TAU);
  g.fill();
  g.strokeStyle = '#8d8268';
  g.lineWidth = 3;
  g.stroke();

  g.fillStyle = '#4b6f7a';
  g.beginPath();
  g.arc(x, y, 17, 0, TAU);
  g.fill();

  g.strokeStyle = '#7a5e39';
  g.lineWidth = 3;
  g.beginPath();
  g.moveTo(x - 22, y - 8);
  g.lineTo(x - 22, y - 34);
  g.moveTo(x + 22, y - 8);
  g.lineTo(x + 22, y - 34);
  g.stroke();
  g.fillStyle = '#8d6c42';
  g.beginPath();
  g.moveTo(x - 34, y - 30);
  g.lineTo(x, y - 50);
  g.lineTo(x + 34, y - 30);
  g.closePath();
  g.fill();
}

function paintOutskirts(
  g: CanvasRenderingContext2D,
  rand: () => number,
  width: number,
  height: number,
): void {
  const outside = (x: number, y: number): boolean =>
    x < WALL.x0 - 46 || x > WALL.x1 + 46 || y < WALL.y0 - 46 || y > WALL.y1 + 46;

  const nearPath = (x: number, y: number): boolean => Math.abs(x - 962) < 104 && y > 838;

  for (let i = 0; i < 130; i++) {
    const x = rand() * width;
    const y = rand() * height;
    if (lakeFree(x, y) && outside(x, y) && !nearPath(x, y)) {
      const radius = 120 + rand() * 240;
      const glow = g.createRadialGradient(x, y, 0, x, y, radius);
      glow.addColorStop(0, 'rgba(52, 80, 38, 0.22)');
      glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      g.fillStyle = glow;
      g.beginPath();
      g.arc(x, y, radius, 0, TAU);
      g.fill();
    }
  }

  const treeSprites: HTMLCanvasElement[] = [];
  for (let i = 0; i < 5; i++) treeSprites.push(makeTreeSprite(rand, 15 + rand() * 7));
  const bushSprites: HTMLCanvasElement[] = [];
  for (let i = 0; i < 4; i++) bushSprites.push(makeBushSprite(rand, 5 + rand() * 3));
  const rockSprites: HTMLCanvasElement[] = [];
  for (let i = 0; i < 3; i++) rockSprites.push(makeRockSprite(rand, 7 + rand() * 4));

  type Decor = { x: number; y: number; sprite: HTMLCanvasElement; scale: number };
  const trees: Decor[] = [];

  for (let i = 0; i < 260; i++) {
    const x = rand() * width;
    const y = rand() * height;
    if (!outside(x, y) || nearPath(x, y)) continue;
    if (rand() > 0.72) continue;
    trees.push({
      x,
      y,
      sprite: treeSprites[Math.floor(rand() * treeSprites.length)],
      scale: 0.85 + rand() * 0.4,
    });
  }

  for (let i = 0; i < 150; i++) {
    const x = rand() * width;
    const y = rand() * height;
    if (!outside(x, y) || nearPath(x, y)) continue;
    const sprite = bushSprites[Math.floor(rand() * bushSprites.length)];
    const scale = 0.8 + rand() * 0.4;
    g.drawImage(
      sprite,
      x - (sprite.width * scale) / 2,
      y - (sprite.height * scale) / 2,
      sprite.width * scale,
      sprite.height * scale,
    );
  }

  for (let i = 0; i < 24; i++) {
    const x = rand() * width;
    const y = rand() * height;
    if (!outside(x, y) || nearPath(x, y)) continue;
    const sprite = rockSprites[Math.floor(rand() * rockSprites.length)];
    const scale = 0.9 + rand() * 0.5;
    g.drawImage(
      sprite,
      x - (sprite.width * scale) / 2,
      y - (sprite.height * scale) / 2,
      sprite.width * scale,
      sprite.height * scale,
    );
  }

  trees.sort((a, b) => a.y - b.y);
  for (const tree of trees) {
    const w = tree.sprite.width * tree.scale;
    const h = tree.sprite.height * tree.scale;
    g.drawImage(tree.sprite, tree.x - w / 2, tree.y - h / 2, w, h);
  }
}

/** Evita decorar em cima da estrada de acesso. */
function lakeFree(x: number, y: number): boolean {
  return !(Math.abs(x - 968) < 60 && y > 900);
}

function paintGrain(g: CanvasRenderingContext2D, rand: () => number, width: number, height: number): void {
  const tile = createCanvas(192, 192);
  const tileCtx = tile.getContext('2d')!;
  const image = tileCtx.createImageData(192, 192);
  const data = image.data;
  for (let i = 0; i < data.length; i += 4) {
    const light = rand() > 0.5;
    data[i] = light ? 214 : 34;
    data[i + 1] = light ? 228 : 48;
    data[i + 2] = light ? 168 : 28;
    data[i + 3] = Math.floor(rand() * 52);
  }
  tileCtx.putImageData(image, 0, 0);

  const pattern = g.createPattern(tile, 'repeat');
  if (!pattern) return;
  g.save();
  g.globalAlpha = 0.5;
  g.fillStyle = pattern;
  g.fillRect(0, 0, width, height);
  g.restore();
}

export function createCity(name: string, seed: number): Scene {
  const width = 1920;
  const height = 1080;
  const rand = mulberry32(seed ^ 0x51ed);

  const canvas = createCanvas(width, height);
  const g = canvas.getContext('2d')!;

  paintGround(g, rand, width, height);
  paintRoads(g);
  paintPlaza(g);
  paintOutskirts(g, rand, width, height);
  paintWalls(g);
  paintFarm(g);
  paintLumberCamp(g);
  paintBarracks(g);
  paintMarket(g);
  paintHouses(g);
  paintWell(g);
  paintCastle(g);
  paintGrain(g, rand, width, height);

  const hotspots: Hotspot[] = [
    {
      id: 'castle',
      name: 'Castelo do Vale',
      kind: 'castle',
      level: 5,
      detail: 'Sede do reino. De aqui saem as ordens e os tributos das aldeias.',
      x: 960,
      y: 442,
      w: 376,
      h: 306,
    },
    {
      id: 'lumber',
      name: 'Serraria',
      kind: 'lumber',
      level: 3,
      detail: 'Lenhadores derrubam e serram a madeira que sustenta as obras.',
      x: 618,
      y: 322,
      w: 312,
      h: 236,
    },
    {
      id: 'farm',
      name: 'Fazendas',
      kind: 'farm',
      level: 4,
      detail: 'Campos de trigo e hortas que alimentam a guarnição e o povo.',
      x: 656,
      y: 726,
      w: 318,
      h: 300,
    },
    {
      id: 'barracks',
      name: 'Quartel',
      kind: 'barracks',
      level: 3,
      detail: 'Pátio de treino onde a infantaria da capital é formada.',
      x: 1314,
      y: 368,
      w: 246,
      h: 276,
    },
    {
      id: 'market',
      name: 'Mercado',
      kind: 'market',
      level: 2,
      detail: 'Tendas de mercadores: troca de grãos, madeira e pedra por ouro.',
      x: 1342,
      y: 702,
      w: 304,
      h: 216,
    },
    {
      id: 'house-smith',
      name: 'Casa do Ferreiro',
      kind: 'house',
      level: 2,
      detail: 'Forja da vila. Abastece o quartel com ferramentas e lâminas.',
      x: 688,
      y: 452,
      w: 134,
      h: 104,
    },
    {
      id: 'house-baker',
      name: 'Casa do Padeiro',
      kind: 'house',
      level: 2,
      detail: 'Fornos acesos de madrugada para o pão de cada dia.',
      x: 1232,
      y: 452,
      w: 134,
      h: 104,
    },
    {
      id: 'house-carpenter',
      name: 'Casa do Carpinteiro',
      kind: 'house',
      level: 2,
      detail: 'Oficina de vigas e telhados, sempre com serragem no chão.',
      x: 1148,
      y: 728,
      w: 130,
      h: 100,
    },
    {
      id: 'well',
      name: 'Poço da Praça',
      kind: 'well',
      level: 1,
      detail: 'Água fresca para a praça e para os animais do curral.',
      x: 878,
      y: 656,
      w: 84,
      h: 100,
    },
  ];

  return {
    name,
    subtitle: 'Capital · centro da cidade',
    width,
    height,
    tileSize: 60,
    canvas,
    hotspots,
  };
}
