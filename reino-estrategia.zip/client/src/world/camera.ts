export interface Point {
  x: number;
  y: number;
}

/** Câmera top-down: centro em coordenadas do mundo, zoom em escala de tela. */
export class Camera {
  x: number;
  y: number;
  zoom = 1;
  minZoom = 0.4;
  maxZoom = 3;
  readonly width: number;
  readonly height: number;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.x = width / 2;
    this.y = height / 2;
  }

  fitTo(viewW: number, viewH: number): void {
    this.zoom = Math.max(this.minZoom, Math.min(viewW / this.width, viewH / this.height));
    this.clamp(viewW, viewH);
  }

  clamp(viewW: number, viewH: number): void {
    const halfW = viewW / (2 * this.zoom);
    const halfH = viewH / (2 * this.zoom);
    this.x = halfW * 2 >= this.width ? this.width / 2 : Math.min(this.width - halfW, Math.max(halfW, this.x));
    this.y = halfH * 2 >= this.height ? this.height / 2 : Math.min(this.height - halfH, Math.max(halfH, this.y));
  }

  screenToWorld(sx: number, sy: number, viewW: number, viewH: number): Point {
    return {
      x: (sx - viewW / 2) / this.zoom + this.x,
      y: (sy - viewH / 2) / this.zoom + this.y,
    };
  }

  zoomAt(factor: number, sx: number, sy: number, viewW: number, viewH: number): void {
    const before = this.screenToWorld(sx, sy, viewW, viewH);
    this.zoom = Math.min(this.maxZoom, Math.max(this.minZoom, this.zoom * factor));
    const after = this.screenToWorld(sx, sy, viewW, viewH);
    this.x += before.x - after.x;
    this.y += before.y - after.y;
    this.clamp(viewW, viewH);
  }
}
