import { clamp01, fbm, lerp, makeNoise, mulberry32, smoothstep } from './noise';

export interface WorldConfig {
  id: string;
  name: string;
  seed: number;
  cols: number;
  rows: number;
  tileSize: number;
}

export enum Tile {
  Grass = 0,
  Water = 1,
  Road = 2,
  Forest = 3,
}

export interface Terrain {
  config: WorldConfig;
  width: number;
  height: number;
  canvas: HTMLCanvasElement;
  tiles: Uint8Array;
  treeCount: number;
}

const TAU = Math.PI * 2;

/** Estrada de terra: da borda oeste até a clareira central. */
const ROAD_POINTS: Array<[number, number]> = [
  [-70, 612],
  [140, 566],
  [330, 598],
  [512, 650],
  [700, 638],
  [836, 600],
  [918, 560],
  [970, 540],
];

/** Lago no canto sudeste (coordenadas do mapa de 1920x1080). */
const LAKE = { x: 1452, y: 832, stretch: 1.5, base: 158 };

/** Clareira aberta no centro — local reservado para a primeira cidade. */
const CLEARING = { x: 966, y: 548, r: 232 };

function catmullRom(
  p0: [number, number],
  p1: [number, number],
  p2: [number, number],
  p3: [number, number],
  t: number,
): [number, number] {
  const t2 = t * t;
  const t3 = t2 * t;
  const x =
    0.5 *
    (2 * p1[0] +
      (-p0[0] + p2[0]) * t +
      (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 +
      (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3);
  const y =
    0.5 *
    (2 * p1[1] +
      (-p0[1] + p2[1]) * t +
      (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 +
      (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3);
  return [x, y];
}

function smoothPath(points: Array<[number, number]>, subdivisions = 14): Array<[number, number]> {
  const out: Array<[number, number]> = [];
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(points.length - 1, i + 2)];
    for (let s = 0; s < subdivisions; s++) {
      out.push(catmullRom(p0, p1, p2, p3, s / subdivisions));
    }
  }
  out.push(points[points.length - 1]);
  return out;
}

function distToPath(x: number, y: number, path: Array<[number, number]>): number {
  let best = Infinity;
  for (let i = 0; i < path.length - 1; i++) {
    const [ax, ay] = path[i];
    const [bx, by] = path[i + 1];
    const dx = bx - ax;
    const dy = by - ay;
    const len2 = dx * dx + dy * dy || 1;
    let t = ((x - ax) * dx + (y - ay) * dy) / len2;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const px = ax + dx * t - x;
    const py = ay + dy * t - y;
    const d = px * px + py * py;
    if (d < best) best = d;
  }
  return Math.sqrt(best);
}

export function createCanvas(width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

/** Árvore estilizada, vista de cima — copa arredondada em três tons. */
export function makeTreeSprite(rand: () => number, radius: number): HTMLCanvasElement {
  const pad = Math.ceil(radius * 1.5) + 4;
  const size = pad * 2;
  const canvas = createCanvas(size, size);
  const g = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  g.fillStyle = 'rgba(20, 38, 14, 0.32)';
  g.beginPath();
  g.ellipse(cx + radius * 0.22, cy + radius * 0.5, radius * 1.04, radius * 0.56, 0, 0, TAU);
  g.fill();

  // silhueta única formada por vários círculos sobrepostos
  const blobs = [{ x: 0, y: 0, r: radius * 0.7 }];
  const count = 6 + Math.floor(rand() * 3);
  for (let i = 0; i < count; i++) {
    const angle = rand() * TAU;
    const dist = rand() * radius * 0.42;
    blobs.push({
      x: Math.cos(angle) * dist,
      y: Math.sin(angle) * dist * 0.9,
      r: radius * (0.32 + rand() * 0.2),
    });
  }

  const silhouette = (): void => {
    g.beginPath();
    for (const blob of blobs) {
      g.moveTo(cx + blob.x + blob.r, cy + blob.y);
      g.arc(cx + blob.x, cy + blob.y, blob.r, 0, TAU);
    }
  };

  g.save();
  silhouette();
  g.clip();
  const light = g.createRadialGradient(
    cx - radius * 0.35,
    cy - radius * 0.42,
    radius * 0.1,
    cx,
    cy,
    radius * 1.25,
  );
  light.addColorStop(0, '#6f9c49');
  light.addColorStop(0.45, '#527d37');
  light.addColorStop(1, '#2d4c1f');
  g.fillStyle = light;
  g.fillRect(0, 0, size, size);

  // mottling de folhagem dentro da copa
  for (let i = 0; i < 5; i++) {
    g.fillStyle = i % 2 === 0 ? 'rgba(30, 56, 21, 0.2)' : 'rgba(132, 176, 92, 0.16)';
    g.beginPath();
    g.ellipse(
      cx + (rand() - 0.5) * radius * 1.1,
      cy + (rand() - 0.5) * radius * 1.0,
      radius * (0.18 + rand() * 0.16),
      radius * (0.14 + rand() * 0.12),
      rand() * TAU,
      0,
      TAU,
    );
    g.fill();
  }
  g.restore();

  silhouette();
  g.strokeStyle = 'rgba(28, 50, 18, 0.4)';
  g.lineWidth = Math.max(1, radius * 0.09);
  g.stroke();

  return canvas;
}

export function makeBushSprite(rand: () => number, radius: number): HTMLCanvasElement {
  const pad = Math.ceil(radius * 2) + 3;
  const size = pad * 2;
  const canvas = createCanvas(size, size);
  const g = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  g.fillStyle = 'rgba(22, 40, 16, 0.22)';
  g.beginPath();
  g.ellipse(cx + 1.5, cy + 3, radius * 1.2, radius * 0.6, 0, 0, TAU);
  g.fill();

  for (let i = 0; i < 4; i++) {
    const angle = rand() * TAU;
    const dist = rand() * radius * 0.5;
    g.fillStyle = i === 0 ? '#2f5122' : '#4a7430';
    g.beginPath();
    g.arc(
      cx + Math.cos(angle) * dist,
      cy + Math.sin(angle) * dist * 0.8,
      radius * (0.45 + rand() * 0.25),
      0,
      TAU,
    );
    g.fill();
  }
  g.fillStyle = '#65903f';
  g.beginPath();
  g.arc(cx - radius * 0.25, cy - radius * 0.3, radius * 0.3, 0, TAU);
  g.fill();

  return canvas;
}

export function makeRockSprite(rand: () => number, radius: number): HTMLCanvasElement {
  const pad = Math.ceil(radius * 2) + 4;
  const size = pad * 2;
  const canvas = createCanvas(size, size);
  const g = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  g.fillStyle = 'rgba(20, 30, 16, 0.25)';
  g.beginPath();
  g.ellipse(cx + 2, cy + radius * 0.5, radius * 1.1, radius * 0.55, 0, 0, TAU);
  g.fill();

  const sides = 6;
  g.beginPath();
  for (let i = 0; i < sides; i++) {
    const angle = (i / sides) * TAU + rand() * 0.2;
    const r = radius * (0.78 + rand() * 0.22);
    const px = cx + Math.cos(angle) * r;
    const py = cy + Math.sin(angle) * r * 0.78;
    if (i === 0) g.moveTo(px, py);
    else g.lineTo(px, py);
  }
  g.closePath();
  g.fillStyle = '#7f8477';
  g.fill();

  g.beginPath();
  g.ellipse(cx - radius * 0.18, cy - radius * 0.28, radius * 0.52, radius * 0.3, -0.4, 0, TAU);
  g.fillStyle = '#9ba095';
  g.fill();

  return canvas;
}

export function createTerrain(config: WorldConfig): Terrain {
  const width = config.cols * config.tileSize;
  const height = config.rows * config.tileSize;
  const seed = config.seed | 0;

  const nGrass = makeNoise(seed + 11);
  const nMoist = makeNoise(seed + 23);
  const nDry = makeNoise(seed + 37);
  const nShore = makeNoise(seed + 53);
  const nForest = makeNoise(seed + 71);
  const nForestFine = makeNoise(seed + 89);
  const nFine = makeNoise(seed + 101);
  const road = smoothPath(ROAD_POINTS);

  // A borda do lago ondula com o ângulo, gerando uma costa irregular.
  const lakeDistance = (x: number, y: number): number => {
    const nx = (x - LAKE.x) / LAKE.stretch;
    const ny = y - LAKE.y;
    const radius = Math.hypot(nx, ny);
    const angle = Math.atan2(ny, nx);
    const wobble = fbm(nShore, Math.cos(angle) * 1.7 + 5, Math.sin(angle) * 1.7 + 5, 3);
    const shore = LAKE.base * (0.7 + 0.52 * wobble);
    return radius - shore;
  };

  const forestDensity = (x: number, y: number): number =>
    fbm(nForest, x / 300, y / 300, 4) * 0.72 + fbm(nForestFine, x / 115, y / 115, 3) * 0.28;

  const clearingDistance = (x: number, y: number): number =>
    Math.hypot(x - CLEARING.x, y - CLEARING.y) - CLEARING.r;

  // --- classificação dos tiles (para gameplay futuro) ----------------------
  const tiles = new Uint8Array(config.cols * config.rows);
  for (let ty = 0; ty < config.rows; ty++) {
    for (let tx = 0; tx < config.cols; tx++) {
      const x = tx * config.tileSize + config.tileSize / 2;
      const y = ty * config.tileSize + config.tileSize / 2;
      let tile = Tile.Grass;
      if (lakeDistance(x, y) < 4) tile = Tile.Water;
      else if (distToPath(x, y, road) < 26) tile = Tile.Road;
      else if (forestDensity(x, y) > 0.53 && clearingDistance(x, y) > 0) tile = Tile.Forest;
      tiles[ty * config.cols + tx] = tile;
    }
  }

  // --- base do terreno em baixa resolução (fica suave e orgânica) ---------
  const scale = 3;
  const low = createCanvas(Math.ceil(width / scale), Math.ceil(height / scale));
  const lowCtx = low.getContext('2d')!;
  const image = lowCtx.createImageData(low.width, low.height);
  const data = image.data;

  for (let py = 0; py < low.height; py++) {
    for (let px = 0; px < low.width; px++) {
      const x = (px + 0.5) * scale;
      const y = (py + 0.5) * scale;

      const grass = fbm(nGrass, x / 420, y / 420, 4);
      const grain = fbm(nFine, x / 70, y / 70, 3);
      const moist = fbm(nMoist, x / 900, y / 900, 3);
      const dryness = smoothstep(0.56, 0.78, fbm(nDry, x / 650, y / 650, 3));

      const t1 = clamp01(grass * 1.55 - 0.12 + (moist - 0.5) * 0.35);
      let r = lerp(56, 108, t1);
      let g = lerp(98, 148, t1);
      let b = lerp(46, 74, t1);

      const t2 = clamp01((grain - 0.35) * 1.4) * 0.3;
      r = lerp(r, 144, t2);
      g = lerp(g, 176, t2);
      b = lerp(b, 96, t2);

      r = lerp(r, 163, dryness * 0.45);
      g = lerp(g, 158, dryness * 0.45);
      b = lerp(b, 98, dryness * 0.45);

      // sub-bosque mais escuro sob as matas
      const clearing = clearingDistance(x, y);
      const shade = smoothstep(0.555, 0.66, forestDensity(x, y)) * (clearing > -30 ? 0.25 : 1);
      r = lerp(r, 46, shade * 0.42);
      g = lerp(g, 78, shade * 0.42);
      b = lerp(b, 37, shade * 0.42);

      // clareira central: pequena praça de terra batida (futuro assentamento)
      const centerDist = clearing + CLEARING.r;
      if (centerDist < 110) {
        const edge = (fbm(nFine, x / 70, y / 70, 3) - 0.5) * 22;
        const dirt = (1 - smoothstep(44 + edge, 96 + edge, centerDist)) * 0.45;
        r = lerp(r, 178, dirt);
        g = lerp(g, 161, dirt);
        b = lerp(b, 114, dirt);
      }

      // areia da margem e água
      const lakeD = lakeDistance(x, y);
      if (lakeD > 0 && lakeD < 18) {
        const t = 1 - lakeD / 18;
        const sand = t * 0.62 * (0.9 + grain * 0.25);
        r = lerp(r, 196, sand);
        g = lerp(g, 186, sand);
        b = lerp(b, 140, sand);
      }
      if (lakeD < 5) {
        const wet = clamp01((5 - lakeD) / 5);
        // mistura distância e ruído para evitar raios saindo do centro
        const depth = clamp01(-lakeD / 105) * 0.55 + fbm(nShore, x / 150 + 11, y / 150 + 7, 3) * 0.45;
        const wr = lerp(146, 50, depth);
        const wg = lerp(199, 116, depth);
        const wb = lerp(196, 134, depth);
        r = lerp(r, wr, wet);
        g = lerp(g, wg, wet);
        b = lerp(b, wb, wet);
      }

      // estrada de terra
      const roadD = distToPath(x, y, road);
      if (roadD < 40) {
        const cover = clamp01((34 - roadD) / 10) * 0.95;
        const texture = 0.9 + grain * 0.2;
        r = lerp(r, 186 * texture, cover);
        g = lerp(g, 159 * texture, cover);
        b = lerp(b, 112 * texture, cover);
      }

      const i = (py * low.width + px) * 4;
      data[i] = r;
      data[i + 1] = g;
      data[i + 2] = b;
      data[i + 3] = 255;
    }
  }
  lowCtx.putImageData(image, 0, 0);

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(low, 0, 0, width, height);

  const rand = mulberry32(seed ^ 0x5f3759df);

  // textura fina: tira o aspecto de plástico liso do capim
  const grainCanvas = createCanvas(192, 192);
  const grainCtx = grainCanvas.getContext('2d')!;
  const grainImage = grainCtx.createImageData(192, 192);
  const grainData = grainImage.data;
  for (let i = 0; i < grainData.length; i += 4) {
    const light = rand() > 0.5;
    grainData[i] = light ? 214 : 32;
    grainData[i + 1] = light ? 228 : 46;
    grainData[i + 2] = light ? 168 : 26;
    grainData[i + 3] = Math.floor(rand() * 62);
  }
  grainCtx.putImageData(grainImage, 0, 0);
  const grainPattern = ctx.createPattern(grainCanvas, 'repeat');
  if (grainPattern) {
    ctx.save();
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = grainPattern;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // --- vegetação ----------------------------------------------------------
  const treeSprites: HTMLCanvasElement[] = [];
  for (let i = 0; i < 5; i++) {
    treeSprites.push(makeTreeSprite(rand, 15 + rand() * 7));
  }
  const bushSprites: HTMLCanvasElement[] = [];
  for (let i = 0; i < 4; i++) {
    bushSprites.push(makeBushSprite(rand, 5 + rand() * 3));
  }
  const rockSprites: HTMLCanvasElement[] = [];
  for (let i = 0; i < 3; i++) {
    rockSprites.push(makeRockSprite(rand, 7 + rand() * 4));
  }

  // tufos de capim espalhados por todo o campo aberto
  ctx.lineCap = 'round';
  for (let i = 0; i < 1500; i++) {
    const x = rand() * width;
    const y = rand() * height;
    if (lakeDistance(x, y) < 18) continue;
    if (distToPath(x, y, road) < 32) continue;
    const alpha = 0.18 + rand() * 0.2;
    ctx.strokeStyle = `rgba(96, 138, 62, ${alpha})`;
    ctx.lineWidth = 1.4;
    for (let blade = 0; blade < 3; blade++) {
      const bx = x + (rand() - 0.5) * 7;
      const lean = (rand() - 0.5) * 4;
      ctx.beginPath();
      ctx.moveTo(bx, y);
      ctx.quadraticCurveTo(bx + lean * 0.5, y - 3, bx + lean, y - 6 - rand() * 3);
      ctx.stroke();
    }
  }

  // flores silvestres em pequenas manchas
  const flowerColors = ['#f4e9b0', '#e7b9c8', '#cfe0f2', '#f0d489'];
  for (let i = 0; i < 520; i++) {
    const x = rand() * width;
    const y = rand() * height;
    if (lakeDistance(x, y) < 20) continue;
    if (distToPath(x, y, road) < 30) continue;
    if (forestDensity(x, y) > 0.52) continue;
    const color = flowerColors[Math.floor(rand() * flowerColors.length)];
    ctx.fillStyle = color;
    ctx.globalAlpha = 0.55 + rand() * 0.35;
    const r = 0.9 + rand() * 0.9;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, TAU);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  // arbustos nas bordas da mata
  for (let gy = 0; gy < height; gy += 78) {
    for (let gx = 0; gx < width; gx += 78) {
      const x = gx + rand() * 78;
      const y = gy + rand() * 78;
      const density = forestDensity(x, y);
      if (density < 0.4 || density > 0.55) continue;
      if (lakeDistance(x, y) < 26 || distToPath(x, y, road) < 38) continue;
      if (clearingDistance(x, y) < 10) continue;
      const sprite = bushSprites[Math.floor(rand() * bushSprites.length)];
      const scale = 0.85 + rand() * 0.4;
      ctx.drawImage(
        sprite,
        x - (sprite.width * scale) / 2,
        y - (sprite.height * scale) / 2,
        sprite.width * scale,
        sprite.height * scale,
      );
    }
  }

  // pedras soltas perto das matas
  for (let i = 0; i < 22; i++) {
    const x = rand() * width;
    const y = rand() * height;
    if (lakeDistance(x, y) < 40) continue;
    if (distToPath(x, y, road) < 60) continue;
    if (forestDensity(x, y) < 0.5) continue;
    const sprite = rockSprites[Math.floor(rand() * rockSprites.length)];
    const scale = 0.8 + rand() * 0.5;
    ctx.drawImage(
      sprite,
      x - (sprite.width * scale) / 2,
      y - (sprite.height * scale) / 2,
      sprite.width * scale,
      sprite.height * scale,
    );
  }

  // árvores: grade com jitter, agrupadas por densidade, desenhadas por Y
  type Tree = { x: number; y: number; sprite: HTMLCanvasElement; scale: number };
  const trees: Tree[] = [];
  const step = 26;
  for (let gy = -step; gy < height + step; gy += step) {
    for (let gx = -step; gx < width + step; gx += step) {
      const x = gx + rand() * step;
      const y = gy + rand() * step;
      const jitter = (rand() - 0.5) * 0.03;
      if (forestDensity(x, y) + jitter < 0.535) continue;
      if (clearingDistance(x, y) < 18) continue;
      if (lakeDistance(x, y) < 30) continue;
      if (distToPath(x, y, road) < 40) continue;
      trees.push({
        x,
        y,
        sprite: treeSprites[Math.floor(rand() * treeSprites.length)],
        scale: 0.85 + rand() * 0.4,
      });
    }
  }
  trees.sort((a, b) => a.y - b.y);
  for (const tree of trees) {
    const w = tree.sprite.width * tree.scale;
    const h = tree.sprite.height * tree.scale;
    ctx.drawImage(tree.sprite, tree.x - w / 2, tree.y - h / 2, w, h);
  }

  return { config, width, height, canvas, tiles, treeCount: trees.length };
}
