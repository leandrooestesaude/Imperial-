/** Área clicável de um edifício, em coordenadas do mundo. */
export interface Hotspot {
  id: string;
  name: string;
  kind: 'castle' | 'farm' | 'lumber' | 'barracks' | 'market' | 'house' | 'well';
  level: number;
  detail: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Uma cena jogável (cidade ou reino) já pré-renderizada em um canvas. */
export interface Scene {
  name: string;
  subtitle: string;
  width: number;
  height: number;
  tileSize: number;
  canvas: HTMLCanvasElement;
  tiles?: Uint8Array;
  hotspots?: Hotspot[];
}
