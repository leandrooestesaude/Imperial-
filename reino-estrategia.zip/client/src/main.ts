import { WorldSocket } from './net';
import type { ConnectionStatus } from './net';
import { Camera } from './world/camera';
import { createCity } from './world/city';
import { createTerrain } from './world/terrain';
import type { WorldConfig } from './world/terrain';
import type { Hotspot, Scene } from './world/scene';

type View = 'city' | 'realm';

const FALLBACK_WORLD: WorldConfig = {
  id: 'local',
  name: 'Vale Esmeralda',
  seed: 20261122,
  cols: 32,
  rows: 18,
  tileSize: 60,
};

const canvas = document.querySelector<HTMLCanvasElement>('#game')!;
const ctx = canvas.getContext('2d', { alpha: false })!;
const el = {
  loading: document.querySelector<HTMLElement>('#loading')!,
  loadingText: document.querySelector<HTMLElement>('#loading-text')!,
  name: document.querySelector<HTMLElement>('#world-name')!,
  meta: document.querySelector<HTMLElement>('#world-meta')!,
  connection: document.querySelector<HTMLElement>('#connection')!,
  players: document.querySelector<HTMLElement>('#players')!,
  coords: document.querySelector<HTMLElement>('#coords')!,
  zoom: document.querySelector<HTMLElement>('#zoom')!,
  panel: document.querySelector<HTMLElement>('#panel')!,
  panelKind: document.querySelector<HTMLElement>('#panel-kind')!,
  panelName: document.querySelector<HTMLElement>('#panel-name')!,
  panelLevel: document.querySelector<HTMLElement>('#panel-level')!,
  panelDetail: document.querySelector<HTMLElement>('#panel-detail')!,
  panelResources: document.querySelector<HTMLElement>('#panel-resources')!,
  panelClose: document.querySelector<HTMLButtonElement>('#panel-close')!,
};

const viewButtons = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-view]'));

const scenes: Partial<Record<View, Scene>> = {};
const cameras: Record<View, Camera> = {
  city: new Camera(1920, 1080),
  realm: new Camera(1920, 1080),
};

let view: View = 'city';
let viewW = 1;
let viewH = 1;
let dpr = 1;
let showGrid = false;
let dragging = false;
let pointer = { x: 0, y: 0 };
let needsRender = true;
let hovered: string | null = null;
let selected: string | null = null;
let dragDistance = 0;
let resourceTimer = 0;
const press = { x: 0, y: 0 };
const keys = new Set<string>();

interface Resource {
  id: 'gold' | 'food' | 'wood' | 'stone';
  label: string;
  value: number;
  rate: number;
}

/** Recursos do reino: sobem sozinhos, como num reino em atividade. */
const resources: Resource[] = [
  { id: 'gold', label: 'Ouro', value: 2480, rate: 14 },
  { id: 'food', label: 'Comida', value: 1860, rate: 11 },
  { id: 'wood', label: 'Madeira', value: 1240, rate: 8 },
  { id: 'stone', label: 'Pedra', value: 860, rate: 5 },
];

const socket = new WorldSocket({
  onStatus: (status) => {
    const labels: Record<ConnectionStatus, string> = {
      connecting: 'Conectando…',
      online: 'Servidor conectado',
      offline: 'Reconectando…',
    };
    el.connection.textContent = labels[status];
    el.connection.dataset['state'] = status;
  },
  onPlayers: (count) => {
    el.players.textContent = String(count);
  },
});

function activeCamera(): Camera {
  return cameras[view];
}

function resize(): void {
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  viewW = window.innerWidth;
  viewH = window.innerHeight;
  canvas.width = Math.round(viewW * dpr);
  canvas.height = Math.round(viewH * dpr);
  canvas.style.width = `${viewW}px`;
  canvas.style.height = `${viewH}px`;
  cameras.city.clamp(viewW, viewH);
  cameras.realm.clamp(viewW, viewH);
  needsRender = true;
}

function fitCamera(target: View): void {
  const scene = scenes[target];
  if (!scene) return;
  const camera = cameras[target];
  camera.x = scene.width / 2;
  camera.y = scene.height / 2;
  camera.fitTo(viewW, viewH);
  if (target === 'city') {
    // em tela larga aproxima da praça; em tela estreita mostra a cidade inteira
    const boost = viewW >= 900 ? 1.18 : 1;
    camera.zoom = Math.min(camera.maxZoom, camera.zoom * boost);
    camera.clamp(viewW, viewH);
  }
}

function updateHeader(): void {
  const scene = scenes[view];
  if (!scene) return;
  el.name.textContent = scene.name;
  el.meta.textContent = scene.subtitle;
  for (const button of viewButtons) {
    button.classList.toggle('active', button.dataset['view'] === view);
  }
}

function updateReadout(): void {
  const scene = scenes[view];
  if (!scene) return;
  const camera = activeCamera();
  const world = camera.screenToWorld(pointer.x, pointer.y, viewW, viewH);
  const inside = world.x >= 0 && world.y >= 0 && world.x < scene.width && world.y < scene.height;
  if (inside) {
    const tx = Math.floor(world.x / scene.tileSize);
    const ty = Math.floor(world.y / scene.tileSize);
    el.coords.textContent = `X ${Math.round(world.x)} · Y ${Math.round(world.y)} · tile ${tx},${ty}`;
  } else {
    el.coords.textContent = '— fora do mapa —';
  }
  el.zoom.textContent = `${Math.round(camera.zoom * 100)}%`;
}

function buildResourceRows(): void {
  el.panelResources.innerHTML = '';
  const swatches: Record<Resource['id'], string> = {
    gold: '#e3c477',
    food: '#c3d47a',
    wood: '#b98a56',
    stone: '#a9b0b8',
  };

  for (const res of resources) {
    const row = document.createElement('div');
    row.className = 'res-row';

    const swatch = document.createElement('span');
    swatch.className = 'res-swatch';
    swatch.style.background = swatches[res.id];

    const label = document.createElement('span');
    label.className = 'res-label';
    label.textContent = res.label;

    const value = document.createElement('strong');
    value.className = 'res-value';
    value.dataset['res'] = res.id;

    const rate = document.createElement('span');
    rate.className = 'res-rate';
    rate.textContent = `+${res.rate}/s`;

    row.append(swatch, label, value, rate);
    el.panelResources.append(row);
  }

  updateResourceReadout();
}

function updateResourceReadout(): void {
  for (const res of resources) {
    const node = el.panelResources.querySelector<HTMLElement>(`[data-res="${res.id}"]`);
    if (node) node.textContent = Math.floor(res.value).toLocaleString('pt-BR');
  }
}

function hotspotAt(x: number, y: number): Hotspot | null {
  const spots = scenes[view]?.hotspots;
  if (!spots) return null;
  for (let i = spots.length - 1; i >= 0; i--) {
    const spot = spots[i];
    if (Math.abs(x - spot.x) <= spot.w / 2 && Math.abs(y - spot.y) <= spot.h / 2) return spot;
  }
  return null;
}

function openPanel(spot: Hotspot): void {
  selected = spot.id;
  el.panelKind.textContent = spot.kind === 'castle' ? 'Sede do reino' : 'Edifício';
  el.panelName.textContent = spot.name;
  el.panelLevel.textContent = String(spot.level);
  el.panelDetail.textContent = spot.detail;
  el.panelResources.hidden = spot.kind !== 'castle';
  updateResourceReadout();
  el.panel.classList.add('open');
  el.panel.setAttribute('aria-hidden', 'false');
  needsRender = true;
}

function closePanel(): void {
  if (selected === null && !el.panel.classList.contains('open')) return;
  selected = null;
  el.panel.classList.remove('open');
  el.panel.setAttribute('aria-hidden', 'true');
  needsRender = true;
}

function render(): void {
  const scene = scenes[view];
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = '#0d150b';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  if (!scene) return;

  const camera = activeCamera();
  const zoom = camera.zoom;
  ctx.setTransform(
    zoom * dpr,
    0,
    0,
    zoom * dpr,
    (viewW / 2 - camera.x * zoom) * dpr,
    (viewH / 2 - camera.y * zoom) * dpr,
  );
  ctx.imageSmoothingEnabled = zoom < 1.02;
  ctx.drawImage(scene.canvas, 0, 0);

  ctx.strokeStyle = 'rgba(14, 24, 10, 0.85)';
  ctx.lineWidth = 6 / zoom;
  ctx.strokeRect(0, 0, scene.width, scene.height);

  if (scene.hotspots) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const spot of scene.hotspots) {
      if (spot.id !== hovered && spot.id !== selected) continue;
      const sx = (spot.x - camera.x) * zoom + viewW / 2;
      const sy = (spot.y - camera.y) * zoom + viewH / 2;
      const w = spot.w * zoom;
      const h = spot.h * zoom;
      const active = spot.id === selected;

      ctx.save();
      ctx.strokeStyle = active ? 'rgba(232, 204, 141, 0.95)' : 'rgba(246, 240, 214, 0.7)';
      ctx.lineWidth = active ? 2.5 : 1.6;
      ctx.setLineDash(active ? [] : [7, 6]);
      ctx.beginPath();
      ctx.roundRect(sx - w / 2, sy - h / 2, w, h, 10);
      ctx.stroke();
      ctx.setLineDash([]);

      const text = `${spot.name} · nível ${spot.level}`;
      ctx.font = '12px "Segoe UI", system-ui, sans-serif';
      const textW = ctx.measureText(text).width;
      const chipX = sx - textW / 2 - 10;
      const chipY = sy - h / 2 - 28;
      ctx.fillStyle = 'rgba(18, 27, 15, 0.86)';
      ctx.beginPath();
      ctx.roundRect(chipX, chipY, textW + 20, 22, 11);
      ctx.fill();
      ctx.strokeStyle = 'rgba(226, 197, 132, 0.4)';
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = '#efe9d9';
      ctx.fillText(text, sx, chipY + 11);
      ctx.restore();
    }
  }

  if (showGrid && view === 'realm') {
    ctx.strokeStyle = 'rgba(240, 248, 224, 0.13)';
    ctx.lineWidth = 1 / zoom;
    ctx.beginPath();
    for (let x = 0; x <= scene.width; x += scene.tileSize) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, scene.height);
    }
    for (let y = 0; y <= scene.height; y += scene.tileSize) {
      ctx.moveTo(0, y);
      ctx.lineTo(scene.width, y);
    }
    ctx.stroke();
  }
}

function setView(next: View): void {
  if (next === view || !scenes[next]) return;
  closePanel();
  hovered = null;
  canvas.style.cursor = '';
  view = next;
  updateHeader();
  updateReadout();
  needsRender = true;
}

let lastFrame = performance.now();

// Só redesenha quando algo muda: sem redraw constante, sem tremor na imagem.
function loop(now: number): void {
  const dt = Math.min(0.05, (now - lastFrame) / 1000);
  lastFrame = now;

  for (const res of resources) res.value += res.rate * dt;
  resourceTimer += dt;
  if (resourceTimer >= 0.25) {
    resourceTimer = 0;
    if (!el.panelResources.hidden) updateResourceReadout();
  }

  const camera = activeCamera();
  const speed = 820 / camera.zoom;
  let moved = false;
  if (keys.has('KeyW') || keys.has('ArrowUp')) {
    camera.y -= speed * dt;
    moved = true;
  }
  if (keys.has('KeyS') || keys.has('ArrowDown')) {
    camera.y += speed * dt;
    moved = true;
  }
  if (keys.has('KeyA') || keys.has('ArrowLeft')) {
    camera.x -= speed * dt;
    moved = true;
  }
  if (keys.has('KeyD') || keys.has('ArrowRight')) {
    camera.x += speed * dt;
    moved = true;
  }
  if (moved) {
    camera.clamp(viewW, viewH);
    updateReadout();
    needsRender = true;
  }

  if (needsRender) {
    render();
    needsRender = false;
  }
  requestAnimationFrame(loop);
}

async function boot(): Promise<void> {
  let world = FALLBACK_WORLD;
  try {
    const response = await fetch('/api/world', { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    world = (await response.json()) as WorldConfig;
  } catch (error) {
    console.warn('[jogo] servidor indisponível, usando configuração local', error);
    el.connection.textContent = 'Modo local (servidor offline)';
    el.connection.dataset['state'] = 'offline';
  }

  await new Promise((resolve) => setTimeout(resolve, 40));
  el.loadingText.textContent = 'Erguendo a capital…';

  const terrain = createTerrain(world);
  scenes.realm = {
    name: world.name,
    subtitle: `Reino · ${terrain.width}×${terrain.height} · semente ${world.seed}`,
    width: terrain.width,
    height: terrain.height,
    tileSize: terrain.config.tileSize,
    canvas: terrain.canvas,
    tiles: terrain.tiles,
  };
  scenes.city = createCity('Capital do Vale', world.seed);
  buildResourceRows();

  resize();
  fitCamera('realm');
  fitCamera('city');
  view = 'city';
  updateHeader();
  updateReadout();

  // primeiro quadro desenhado antes de revelar, evitando flash de tela vazia
  render();
  el.loading.classList.add('hidden');

  socket.connect();
  requestAnimationFrame(loop);
}

// --- entrada --------------------------------------------------------------

for (const button of viewButtons) {
  button.addEventListener('click', () => {
    const next = button.dataset['view'] as View | undefined;
    if (next) setView(next);
  });
}

canvas.addEventListener('pointerdown', (event) => {
  dragging = true;
  dragDistance = 0;
  press.x = event.clientX;
  press.y = event.clientY;
  canvas.classList.add('dragging');
  canvas.setPointerCapture(event.pointerId);
  pointer = { x: event.clientX, y: event.clientY };
});

canvas.addEventListener('pointermove', (event) => {
  const dx = event.clientX - pointer.x;
  const dy = event.clientY - pointer.y;
  if (dragging) {
    dragDistance += Math.hypot(dx, dy);
    const camera = activeCamera();
    camera.x -= dx / camera.zoom;
    camera.y -= dy / camera.zoom;
    camera.clamp(viewW, viewH);
    needsRender = true;
  }
  pointer = { x: event.clientX, y: event.clientY };
  updateReadout();

  // realce do edifício sob o cursor (não enquanto arrasta o mapa)
  const camera = activeCamera();
  const world = camera.screenToWorld(pointer.x, pointer.y, viewW, viewH);
  const spot = dragging ? null : hotspotAt(world.x, world.y);
  const nextHover = spot ? spot.id : null;
  if (nextHover !== hovered) {
    hovered = nextHover;
    canvas.style.cursor = nextHover ? 'pointer' : '';
    needsRender = true;
  }
});

const stopDrag = (event: PointerEvent): void => {
  const clicked = dragging && dragDistance < 7;
  dragging = false;
  canvas.classList.remove('dragging');
  if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
  if (!clicked) {
    needsRender = true;
    return;
  }

  const world = activeCamera().screenToWorld(press.x, press.y, viewW, viewH);
  const spot = hotspotAt(world.x, world.y);
  if (spot) openPanel(spot);
  else closePanel();
};
canvas.addEventListener('pointerup', stopDrag);
canvas.addEventListener('pointercancel', (event) => {
  dragDistance = 999;
  stopDrag(event);
});
canvas.addEventListener('pointerleave', () => {
  if (hovered === null) return;
  hovered = null;
  canvas.style.cursor = '';
  needsRender = true;
});

canvas.addEventListener(
  'wheel',
  (event) => {
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.12 : 1 / 1.12;
    activeCamera().zoomAt(factor, event.clientX, event.clientY, viewW, viewH);
    updateReadout();
    needsRender = true;
  },
  { passive: false },
);

el.panelClose.addEventListener('click', () => closePanel());

window.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    closePanel();
    return;
  }
  if (event.key === 'Tab') {
    event.preventDefault();
    setView(view === 'city' ? 'realm' : 'city');
    return;
  }
  if (event.key === 'g' || event.key === 'G') {
    showGrid = !showGrid;
    needsRender = true;
    return;
  }
  if (event.key === '+' || event.key === '=') {
    activeCamera().zoomAt(1.15, viewW / 2, viewH / 2, viewW, viewH);
    updateReadout();
    needsRender = true;
    return;
  }
  if (event.key === '-') {
    activeCamera().zoomAt(1 / 1.15, viewW / 2, viewH / 2, viewW, viewH);
    updateReadout();
    needsRender = true;
    return;
  }
  keys.add(event.code);
});

window.addEventListener('keyup', (event) => keys.delete(event.code));
window.addEventListener('blur', () => keys.clear());
window.addEventListener('resize', () => {
  resize();
  updateReadout();
});

void boot();
