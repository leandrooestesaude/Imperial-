export type ConnectionStatus = 'connecting' | 'online' | 'offline';

export interface NetHandlers {
  onStatus: (status: ConnectionStatus) => void;
  onPlayers: (count: number) => void;
}

/** Conexão WebSocket com o servidor, com reconexão automática. */
export class WorldSocket {
  private socket: WebSocket | null = null;
  private retry = 0;
  private timer: number | null = null;
  private closedByUser = false;
  status: ConnectionStatus = 'offline';

  constructor(private readonly handlers: NetHandlers) {}

  connect(): void {
    this.closedByUser = false;
    this.socket?.close();
    this.setStatus('connecting');

    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = new WebSocket(`${protocol}//${location.host}/ws`);
    this.socket = socket;

    socket.onopen = () => {
      this.retry = 0;
      this.setStatus('online');
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(String(event.data)) as { t?: string; count?: number };
        if (message.t === 'players' && typeof message.count === 'number') {
          this.handlers.onPlayers(message.count);
        }
      } catch {
        // mensagem inválida: ignora
      }
    };

    socket.onclose = () => {
      this.socket = null;
      this.setStatus('offline');
      if (!this.closedByUser) this.scheduleRetry();
    };

    socket.onerror = () => socket.close();
  }

  dispose(): void {
    this.closedByUser = true;
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.socket?.close();
  }

  private scheduleRetry(): void {
    if (this.timer !== null) return;
    const delay = Math.min(8000, 600 * 2 ** this.retry++);
    this.timer = window.setTimeout(() => {
      this.timer = null;
      this.connect();
    }, delay);
  }

  private setStatus(status: ConnectionStatus): void {
    this.status = status;
    this.handlers.onStatus(status);
  }
}
