import http from 'node:http';
import { randomUUID } from 'node:crypto';
import { WebSocketServer } from 'ws';
import { WORLD } from './world.js';

const PORT = Number(process.env.PORT ?? 8787);
const startedAt = Date.now();

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(payload),
  });
  res.end(payload);
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);

  if (req.method !== 'GET') {
    sendJson(res, 405, { error: 'método não permitido' });
    return;
  }

  if (url.pathname === '/api/health') {
    sendJson(res, 200, {
      ok: true,
      uptime: Math.round((Date.now() - startedAt) / 1000),
      players: players.size,
    });
    return;
  }

  if (url.pathname === '/api/world') {
    sendJson(res, 200, WORLD);
    return;
  }

  sendJson(res, 404, { error: 'rota não encontrada' });
});

/** id -> { socket } — por enquanto o servidor só acompanha presença. */
const players = new Map();

const wss = new WebSocketServer({ server, path: '/ws' });

function broadcast(message, exceptId) {
  const payload = JSON.stringify(message);
  for (const [id, player] of players) {
    if (id === exceptId) continue;
    if (player.socket.readyState === 1) player.socket.send(payload);
  }
}

function announcePlayers() {
  broadcast({ t: 'players', count: players.size });
}

wss.on('connection', (socket) => {
  const id = randomUUID();
  players.set(id, { socket, joinedAt: Date.now() });

  socket.send(JSON.stringify({ t: 'welcome', id, world: WORLD, count: players.size }));
  console.log(`[ws] jogador ${id.slice(0, 8)} entrou (total ${players.size})`);
  announcePlayers();

  socket.on('message', (raw) => {
    let message;
    try {
      message = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (message?.t === 'ping') socket.send(JSON.stringify({ t: 'pong' }));
  });

  socket.on('close', () => {
    players.delete(id);
    console.log(`[ws] jogador ${id.slice(0, 8)} saiu (total ${players.size})`);
    announcePlayers();
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[servidor] http://0.0.0.0:${PORT} · mundo ${WORLD.name} ${WORLD.width}x${WORLD.height}`);
});
