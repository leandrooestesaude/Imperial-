// Configuração do mundo. O cliente gera o terreno a partir da semente,
// então servidor e clientes sempre partem do mesmo mapa.
export const TILE_SIZE = 60;

export const WORLD = {
  id: 'vale-esmeralda',
  name: 'Vale Esmeralda',
  seed: 20261122,
  cols: 32,
  rows: 18,
  tileSize: TILE_SIZE,
  version: 1,
  width: 32 * TILE_SIZE, // 1920
  height: 18 * TILE_SIZE, // 1080
};
